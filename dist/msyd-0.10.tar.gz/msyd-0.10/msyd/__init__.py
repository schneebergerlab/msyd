#!/usr/bin/env python3
__version__ = "0.10"

from .main import main
if __name__ == '__main__':
    main()
